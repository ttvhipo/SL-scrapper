import requests
import folium
import threading
import time
from flask import Flask, render_template_string, jsonify
from google.transit import gtfs_realtime_pb2
from folium.plugins import MarkerCluster
from time import sleep
from threading import Lock

# Flask app setup
app = Flask(__name__)

# Global variable to store the map object in memory
my_map_html = ""
# Lock to ensure thread safety when updating the map
map_lock = Lock()

# Function to fetch and update vehicle data with retries
def fetch_bus_data():
    global my_map_html
    url = 'https://opendata.samtrafiken.se/gtfs-rt-sweden/sl/VehiclePositionsSweden.pb?key=55d7e64ffaff42acafaedfdee46c3788'

    retry_count = 5
    for _ in range(retry_count):
        try:
            # Fetch the data
            response = requests.get(url)
            response.raise_for_status()  # Check for HTTP errors

            # Decode the protobuf data
            feed = gtfs_realtime_pb2.FeedMessage()
            feed.ParseFromString(response.content)

            # Create a base map centered around Stockholm
            map_center = [59.3293, 18.0686]  # Stockholm coordinates
            map_object = folium.Map(location=map_center, zoom_start=12)
            marker_cluster = MarkerCluster().add_to(map_object)

            # Extract vehicle positions and plot them on the map
            for entity in feed.entity:
                if entity.HasField('vehicle'):
                    vehicle = entity.vehicle
                    if hasattr(vehicle.position, 'latitude') and hasattr(vehicle.position, 'longitude'):
                        lat = vehicle.position.latitude
                        lon = vehicle.position.longitude

                        # Get vehicle ID
                        vehicle_id = getattr(vehicle, 'id', 'No ID available')

                        # Add the vehicle's location to the map
                        folium.Marker([lat, lon], popup=f"Vehicle ID: {vehicle_id}").add_to(marker_cluster)

            # Save the map as an HTML string
            with map_lock:
                my_map_html = map_object._repr_html_()  # Store the map as HTML string
            
            return True  # Successful fetch

        except requests.exceptions.RequestException as e:
            print(f"Error fetching bus data: {e}")
            sleep(2)  # Wait before retrying
    return False  # Failed after retries

# Function to run the data fetch periodically
def periodic_update():
    while True:
        if fetch_bus_data():  # Fetch the bus data and update the map
            print("Bus data updated successfully")
        else:
            print("Failed to fetch bus data after retries.")
        time.sleep(4)  # Wait for 4 seconds before fetching again

# Route to serve the map on a web page
@app.route('/')
def index():
    # Serve the map stored in the global variable
    with map_lock:
        return render_template_string(my_map_html)

@app.route('/update_map')
def update_map():
    # Generate and return the latest map (only the map part, not the full page)
    fetch_bus_data()  # Update the map data
    with map_lock:
        return jsonify({"map_html": my_map_html})

if __name__ == "__main__":
    # Start the periodic update in a separate thread so it doesn't freeze the app
    threading.Thread(target=periodic_update, daemon=True).start()

    # Run Flask server to serve the map
    app.run(debug=True, use_reloader=False)
